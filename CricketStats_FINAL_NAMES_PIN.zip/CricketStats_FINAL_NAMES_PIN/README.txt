Admin PIN: 44990

IMPORTANT:
In your Google Apps Script Code.gs, set:
ADMIN_PIN: '44990'
Then Save and Deploy a new version.

The included index.html fixes player-name display for backend data that uses the `player` field.
